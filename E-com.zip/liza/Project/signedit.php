<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "shopping";

// Connection build
$conn = mysqli_connect($servername, $username, $password, $db_name);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['eid'])) {
    $id = $_GET['eid'];

    // Fetch the current data
    $sql = "SELECT * FROM signupshop WHERE id=$id";
    $result = mysqli_query($conn, $sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "No record found";
    }
}

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    $date = $_POST['date'];
    $address = $_POST['address'];

    $sql = "UPDATE signupshop SET firstname='$firstname', lastname='$lastname', email='$email', password='$password', phone='$phone', date='$date', address='$address' WHERE id=$id";

    if (mysqli_query($conn, $sql)) {
        header("Location: shopsignup.php"); // Redirect to the shopsignup.php page after successful update
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Account Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 0;
        }

        form {
            margin-top: 50px;
            background: #fff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 40%;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }
        input, textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        textarea {
            height: 80px;
        }

        .submit {
            background-color: #d56d5a;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 4px;
            width: 100%;
        }

        .submit:hover {
            background-color: #c68b80;
        }
    </style>
</head>
<body>
    <form action="signedit.php" method="post">
        <h1 style="display: flex; justify-content: center;">Edit Account Details</h1>
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        <label for="firstname">First Name:</label>
        <input type="text" id="firstname" name="firstname" value="<?php echo $row['firstname']; ?>" placeholder="Enter your first name"><br>
        <label for="lastname">Last Name:</label>
        <input type="text" id="lastname" name="lastname" value="<?php echo $row['lastname']; ?>" placeholder="Enter your last name"><br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo $row['email']; ?>" placeholder="Enter your email" required><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" value="<?php echo $row['password']; ?>" placeholder="Enter the password" required><br>
        <label for="phone">Phone Number:</label>
        <input type="text" id="phone" name="phone" value="<?php echo $row['phone']; ?>" placeholder="Enter your number"><br>
        <label for="date">Date of Birth:</label>
        <input type="date" id="dob" name="date" value="<?php echo $row['date']; ?>"><br>
        <label for="address">Address:</label>
        <textarea id="address" name="address"><?php echo $row['address']; ?></textarea><br>
        <input class="submit" type="submit" name="update" value="Update">
    </form>
</body>
</html>
