<?php
session_start();

// Fetch the total amount from the session
$paymentamount = isset($_SESSION['total']) ? $_SESSION['total'] : 0.00;

$servername = "localhost";
$username = "root";
$password = "";
$db_name = "shopping";

$conn = mysqli_connect($servername, $username, $password, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $account = $_POST['account'];
    $cvv = $_POST['cvv'];
    $expiryDate = $_POST['expiryDate'];
    $paymentAmount = $paymentamount; // Use the total amount stored in the session

    $select = "SELECT * FROM pay WHERE account= '$account' AND cvv='$cvv' AND ExD='$expiryDate'";
    $query = mysqli_query($conn, $select);

    if (!$query) {
        echo "<div class='error'>Query unsuccessful: " . mysqli_error($conn) . "</div>";
    } else {
        $result = mysqli_num_rows($query);
        if ($result == 1) {
            $row = mysqli_fetch_assoc($query);
            if ($row['Amount'] >= $paymentAmount) {
                $newAmount = $row['Amount'] - $paymentAmount;
                $update = "UPDATE pay SET Amount='$newAmount' WHERE account='$account'";

                if (mysqli_query($conn, $update)) {
                    echo "<div class='success'>Payment successful. Your new balance is: $" . number_format($newAmount, 2) . "</div>";
                } else {
                    echo "<div class='error'>Error updating account balance: " . mysqli_error($conn) . "</div>";
                }
            } else {
                echo "<div class='error'>Insufficient funds!</div>";
            }
        } else {
            echo "<div class='error'>Invalid account details!</div>";
        }
    }
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <style>
        body {
            background-color: #F5F5F5;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background-color: #800000;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .navbar a {
            color: #FFFFFF;
            text-decoration: none;
            font-size: 18px;
            padding: 10px;
        }
        .navbar a:hover {
            background-color: #660000;
            border-radius: 4px;
        }
        .inner {
            background-color: #FFFFFF;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            margin: 50px auto;
        }
        h1 {
            color: #800000;
            text-align: center;
            margin-bottom: 20px;
        }
        .input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #DDD;
            border-radius: 4px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #800000;
            color: #FFFFFF;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #660000;
        }
        .error {
            color: #FF0000;
            text-align: center;
            margin-top: 10px;
        }
        .success {
            color: #008000;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="ShoppingWebsite.php">
            <i class="fas fa-home"></i> Home
        </a>
    </div>
    <div class="inner">
        <form class="form" method="POST">
            <h1>Payment Here</h1>
            <div>
                <input type="text" name="account" class="input" placeholder="Enter your account" required>
            </div>
            <div>
                <input type="text" name="cvv" class="input" placeholder="Enter your CVV" required>
            </div>
            <div>
                <input type="text" name="expiryDate" class="input" placeholder="Enter expiry date" required>
            </div>
            <?php
                echo "<p style='color:black;'>Your total bill to payout: $ " . number_format($paymentamount, 2) . "</p>";
            ?>
            <button name="pay">Pay</button>
        </form>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
</body>
</html>