<?php
session_start(); 
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "shopping";
$conn = mysqli_connect($servername, $username, $password, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['id'])) {
    $product_id = intval($_GET['id']);

    $sql = "SELECT * FROM product WHERE id = $product_id";
    $result = mysqli_query($conn, $sql);

    if ($result->num_rows > 0) {
        $product = mysqli_fetch_assoc($result);
    } else {
        echo "Product not found!";
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $quantity = intval($_POST['quantity']);
        $payment_method = $_POST['payment_method'];

        if ($quantity > 0 && $quantity <= $product['productquantity']) {
            // Save the order details in the session
            $_SESSION['product_id'] = $product_id;
            $_SESSION['quantity'] = $quantity;
            $_SESSION['payment_method'] = $payment_method;
            $_SESSION['total_amount'] = $product['p_price'] * $quantity;

            switch($payment_method) {
                case 'Bank Account':
                    header("Location: payment.php");
                    break;
               
                case 'Cash on Delivery':
                    header("Location: Cash.php");
                    break;
                default:
                    echo "Invalid payment method!";
                    exit;
            }
            exit;
        } else {
            echo "Invalid quantity or out of stock!";
        }
    }
} else {
    echo "No product ID specified!";
    exit;
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buy Product</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <style>
        .navbar {
            background-color: #65000B;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            color: white;
        }
        .navbar .navbar-brand {
            font-size: 1.5rem;
            color: white;
        }
        .navbar .nav-link {
            color: #ffffff;
            margin-left: 20px;
        }
        .navbar .nav-link:hover {
            color: #ffbb00;
        }
        .container {
            padding: 20px;
        }
        .card {
            display: flex;
            align-items: center;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: #f5f5f5;
            padding: 20px;
            margin: 20px 0;
        }
        .card img {
            max-width: 300px;
            border-radius: 8px;
            margin-right: 20px;
        }
        .card-body {
            flex: 1;
        }
        .card-title {
            font-size: 1.5rem;
            margin-bottom: 10px;
        }
        .card-text {
            margin-bottom: 10px;
        }
        .btn-dark {
            background-color: #65000B;
            border-color: #65000B;
        }
        .btn-dark:hover {
            background-color: #50000A;
            border-color: #50000A;
        }
        .quantity-controls {
            display: flex;
            align-items: center;
        }
        .quantity-controls button {
            background: #65000B;
            color: white;
            border: none;
            padding: 5px 10px;
            margin: 0 5px;
            cursor: pointer;
        }
        .quantity-controls input {
            text-align: center;
            width: 60px;
            border: 1px solid #ddd;
            padding: 5px;
        }
        .payment-methods {
            margin-top: 20px;
        }
        .payment-methods label {
            margin-right: 10px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="#">HIJABI</a>
    <div class="collapse navbar-collapse nav-button" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
                <a class="nav-link" href="ShoppingWebsite.php">Home</a>
            </li>
            <a class="nav-link" href="Addtocart.php"><i class="fas fa-shopping-cart"></i> Cart</a>
        </ul>
    </div>
</nav>
    <div class="container">
        <div class="card">
            <img src="uploads/<?php echo $product['image']; ?>" alt="Product Image" class="card-img-top">
            <div class="card-body">
                <h5 class="card-title"><?php echo $product['productname']; ?></h5>
                <p class="card-text">Quantity: <?php echo $product['productquantity']; ?></p>
                <p class="card-text">Price: $<?php echo $product['p_price']; ?></p>
                <p class="card-text">Type: <?php echo $product['producttype']; ?></p>
                <form method="POST">
                    <div class="quantity-controls">
                        <button type="button" onclick="changeQuantity(-1)">-</button>
                        <input type="number" id="quantity" name="quantity" value="1" min="1" max="<?php echo $product['productquantity']; ?>">
                        <button type="button" onclick="changeQuantity(1)">+</button>
                    </div>
                    <div class="payment-methods">
                        <label><input type="radio" name="payment_method" value="Bank Account" required> Bank Account</label>
                        
                        <label><input type="radio" name="payment_method" value="Cash on Delivery" required> Cash on Delivery</label>
                    </div>
                    <button type="submit" class="btn btn-dark">Purchase</button>
                </form>
            </div>
        </div>
    </div>
    <script>
        function changeQuantity(amount) {
            var quantityInput = document.getElementById('quantity');
            var currentQuantity = parseInt(quantityInput.value);
            var maxQuantity = parseInt(quantityInput.getAttribute('max'));
            if (currentQuantity + amount > 0 && currentQuantity + amount <= maxQuantity) {
                quantityInput.value = currentQuantity + amount;
            }
        }
    </script>
</body>
</html>
