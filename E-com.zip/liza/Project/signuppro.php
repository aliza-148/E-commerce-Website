<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "shopping";

$conn = mysqli_connect($servername, $username, $password, $db_name);

// Check connection
if (!$conn) {
    die("Connection failed: ");
}

$Username = $_POST['Username'];
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$confirmpassword = $_POST['confirmpassword'];
$phone = $_POST['phone'];
$date = $_POST['date']; // Assuming $date holds the actual date value
$address = $_POST['address'];

if ($password !== $confirmpassword) {
    echo "<script>
            alert('Passwords do not match. Please try again.');
            window.location.href = 'ShoppingWebsite.html';
          </script>";
    exit();
}

$sql = "SELECT * FROM signupshop WHERE email = '$email'";
$result = mysqli_query($conn, $sql);

if ($result) {
    if (mysqli_num_rows($result) > 0) {
        echo "<script>
                alert('Email already exists. Please use a different email.');
                window.location.href = 'ShoppingWebsite.html';
              </script>";
        exit();
    }
} else {
    echo "Error: " ;
    exit();
}

$sql = "INSERT INTO signupshop (Username, name, email, password, phone, date, address)
        VALUES('$Username' ,'$name','$email','$password','$phone','$date' ,'$address')";

if ($conn->query($sql) === TRUE) {
    echo "<script>
            alert('Signup successful!');
            window.location.href = 'shoplogin.php';
          </script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>