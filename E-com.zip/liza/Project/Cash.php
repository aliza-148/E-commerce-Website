<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cash on Delivery</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 20px;
}

h1 {
    text-align: center;
}

form {
    max-width: 600px;
    margin: auto;
    padding: 20px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

fieldset {
    border: none;
    margin-bottom: 15px;
}

legend {
    font-weight: bold;
    margin-bottom: 10px;
    font-size: 1.2em;
}

label {
    display: block;
    margin-bottom: 5px;
}

input[type="text"],
input[type="tel"],
input[type="email"],
input[type="number"],
textarea {
    width: 100%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
    margin-bottom: 10px;
}

button {
    background-color: #65000b;
    color: #fff;
    border: none;
    padding: 10px 20px;
    font-size: 1em;
    border-radius: 4px;
    cursor: pointer;
}

button:hover {
    background-color: #218838;
}

    </style>
</head>
<body>
    <h1>Delivery Information</h1>
    <form action="process_order.php" method="POST">
        <fieldset>
            <legend>Customer Information</legend>
            <label for="name">Full Name:</label>
            <input type="text" id="name" name="name" required><br>

            <label for="phone">Phone Number:</label>
            <input type="tel" id="phone" name="phone" required><br>

            <label for="email">Email Address:</label>
            <input type="email" id="email" name="email" required>
        </fieldset>

        <fieldset>
            <legend>Delivery Address</legend>
            <label for="address">Street Address:</label>
            <input type="text" id="address" name="address" required><br>

            <label for="city">City:</label>
            <input type="text" id="city" name="city" required><br>

            <label for="state">State/Province/Region:</label>
            <input type="text" id="state" name="state" required><br>

            <label for="postal_code">Postal Code:</label>
            <input type="text" id="postal_code" name="postal_code" required><br>

            <label for="country">Country:</label>
            <input type="text" id="country" name="country" required>
        </fieldset>

        <fieldset>
            <legend>Order Details</legend>
            <label for="products">Products (List of products and quantities):</label>
            <textarea id="products" name="products" rows="4" required></textarea><br>

            <label for="total_amount">Total Amount:</label>
            <input type="number" id="total_amount" name="total_amount" step="0.01" required>
        </fieldset>

        <fieldset>
            <legend>Additional Instructions</legend>
            <label for="instructions">Special Instructions:</label>
            <textarea id="instructions" name="instructions" rows="2"></textarea>
        </fieldset>

        <input type="hidden" name="payment_method" value="cash_on_delivery">
        <button type="submit">Place Order</button>
    </form>
</body>
</html>
