<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$db_name = "shopping";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve user_id from session
$user_id = isset($_SESSION['id']) ? $_SESSION['id'] : 0;

// Retrieve cart count for the logged-in user
$cart_count = 0;
$sql = "SELECT COUNT(*) as count FROM cart WHERE user_id='$user_id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $cart_count = $row['count'];
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Georeggte</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
          integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
          crossorigin="anonymous" referrerpolicy="no-referrer"/>    <style>
        body {
            padding: 17px;
            background-color: white;
            background-size: cover;
            
            transition: all 1s ease;
        }

        .navbar {
            background-color: #65000B;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            color: white;
        }

        .navbar .navbar-brand {
            font-size: 1.5rem;
            color: white;
        }

        .navbar .nav-link {
            color: #ffffff;
            margin-left: 20px;
        }

        .navbar .nav-link:hover {
            color: #ffbb00;
        }

        .navbar .fa-shopping-cart {
            color: #ffffff;
            margin-left: 1rem;
            position: relative;
        }

        .navbar .fa-shopping-cart::after {
            content: "<?php echo $cart_count; ?>";
            position: absolute;
            top: -10px;
            right: -10px;
            background-color: red;
            color: white;
            border-radius: 50%;
            padding: 2px 5px;
            font-size: 12px;
        }

        .row {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 1rem;
        }

        .col-lg-3 {
            border: 1px solid #ddd;
            border-radius: 20px;
            box-shadow: 0 0 10px rgba(53, 81, 193, 0.1);
            background-color: #f5f5f5;
            padding: 17px;
            text-align: center;
        }

        .img-fluid {
            border-radius: 10px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            max-width: 100%;
            height: auto;
            margin-bottom: 1rem;
        }

        .img-fluid:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        h3 {
            margin-bottom: 0.5rem;
        }

        p {
            margin: 0.5rem 0;
        }

        button {
            margin-top: 1rem;
            background-color:#65000b;
        }

        .card-container {
            display: flex;
            flex-wrap: wrap;
            gap: 16px;
        }

        .card {
            border: 1px solid #ccc;
            border-radius: 8px;
            width: calc(33.333% - 16px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 16px;
            text-align: center;
        }

        .card img {
            max-width: 50%;
            height: auto;
            border-radius: 4px;
        }

        .card h3 {
            font-size: 1.25em;
            margin: 0.5em 0;
        }

        .card p {
            margin: 0.25em 0;
        }

        .card .actions {
            margin-top: 1em;
        }

        .card .actions a {
            text-decoration: none;
            color: #007bff;
            margin: 0 8px;
            transition: color 0.3s;
        }

        .card .actions a:hover {
            color: #0056b3;
        }
        .btn btn-dark {
        }
    </style>

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#">HIJABI</a>
        <div class="collapse navbar-collapse nav-button" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="ShoppingWebsite.php">Home</a>
                </li>
                
</ul>
          <a class="nav-link" href="Addtocart.php"><i class="fas fa-shopping-cart"></i> Cart</a>
        </div>
    </nav>
    <br>
    <br>
    <br>
    <br>
    <!-- <div class="row">
 -->

    <div class="card-container">
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $db_name = "shopping";

        $conn = mysqli_connect($servername, $username, $password, $db_name);
        
        $sql = "SELECT * FROM product where producttype = 'Chiffon'";
        $result = mysqli_query($conn, $sql);

        if ($result->num_rows > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<div class='card'>";
                echo "<img src='uploads/" . $row['image'] . "' alt='Product Image'>";
                echo "<h3>" . $row['productname'] . "</h3>";
                echo "<p>Quantity: " . $row['productquantity'] . "</p>";
                echo "<p>Price: $" . $row['p_price'] . "</p>";
                echo "<p>Type: " . $row['producttype'] . "</p>";
                echo "<div class='actions'>";
                echo "<a href='buy.php?id=" . $row['id'] . "' class='btn btn-dark'>Buy</a>";
                echo "<a href='cart.php?id=" . $row['id'] . "' class='btn btn-dark'>Add to cart</a>";

                echo  "</div>";

                echo "</div>";
            }
        } else {
            echo "<p>No records found</p>";

        }
        $conn->close();
        ?>
    </div>
</body>

</html>
