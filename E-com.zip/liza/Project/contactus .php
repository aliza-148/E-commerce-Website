<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    var_dump($_POST);
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "shopping";

// Connection build
$conn = mysqli_connect($servername, $username, $password, $db_name);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve user input
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// Check if email already exists
$sql = "SELECT `id`, `name`, `email`, `message`, `submitted_at` FROM `contact` WHERE 1";
$result = mysqli_query($conn, $sql);

if ($result && mysqli_num_rows($result) > 0) {
    echo "<script>
            alert('Email already exists. Please use a different email.');
            window.location.href = 'Contact.php';
          </script>";
    exit();
}

// Insert data into database
$sql = "INSERT INTO `contact`(`id`, `name`, `email`, `message`, `submitted_at`) 
VALUES ('[id]','[name]','[email]','[message]','[submitted_at]') NOW())";
if (mysqli_query($conn, $sql)) {
    echo "<script>
            alert('Submit successful!');
            window.location.href = 'Contact.php';
          </script>";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
}
?>
