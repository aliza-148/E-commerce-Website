<?php

// Check if upload form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

  // Connect to MySQL database (replace with your credentials)
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "hr_products";

  $conn = new mysqli($servername, $username, $password, $dbname);

  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Get uploaded file information
  $image_name = $_FILES['item-image']['name'];
  $image_tmp_name = $_FILES['item-image']['tmp_name'];
  $image_size = $_FILES['item-image']['size'];
  $image_error = $_FILES['item-image']['error'];

  // Get form data
  $name = $_POST['item-name'];
  $details = $_POST['item-details'];
  $price = $_POST['item-price'];

  // Validate uploaded image
  if ($image_error === 0) {
    if ($image_size <= 1000000) { // Limit image size to 1MB (adjust as needed)
      $image_ext = strtolower(pathinfo($image_name, PATHINFO_EXTENSION));
      $allowed_extensions = array("jpg", "jpeg", "png", "gif");

      if (in_array($image_ext, $allowed_extensions)) {
        // Generate a unique filename for the image
        $new_image_name = uniqid('', true) . '.' . $image_ext;

        // Upload the image to the uploads folder
        $upload_path = "uploads/" . $new_image_name;
        if (move_uploaded_file($image_tmp_name, $upload_path)) {

          // Prepare SQL statement
          $sql = "INSERT INTO items (image, name, details, price) VALUES (?, ?, ?, ?)";
          $stmt = $conn->prepare($sql);
          $stmt->bind_param("ssss", $new_image_name, $name, $details, $price);

          // Execute the query
          if ($stmt->execute()) {
            header("location:hr.php");
            echo "<script>alert('Item uploaded successfully!');</script>";
          } else {
            echo "Error: " . $conn->error;
          }

          $stmt->close();
        } else {
          echo "Error uploading image!";
        }
      } else {
        echo "Invalid image format!";
      }
    } else {
      echo "Image size is too large!";
    }
  } else {
    echo "Error uploading image: " . $image_error;
  }

  $conn->close();
}

?>
