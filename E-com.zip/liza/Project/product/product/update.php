<?php
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];
    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "hr_products";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch product details
    $sql = "SELECT * FROM items WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        // Display update form
        echo "<h2>Update Product</h2>";
        echo "<form action='update_process.php' method='post' enctype='multipart/form-data'>";
        echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";
        echo "<label for='name'>Name:</label>";
        echo "<input type='text' name='name' id='name' value='" . $row['name'] . "'><br>";
        echo "<label for='price'>Price:</label>";
        echo "<input type='text' name='price' id='price' value='" . $row['price'] . "'><br>";
        echo "<label for='details'>Details:</label>";
        echo "<textarea name='details' id='details'>" . $row['details'] . "</textarea><br>";
        echo "<label for='image'>Image:</label>";
        echo "<input type='file' name='image' id='image'><br>";
        echo "<input type='submit' value='Update'>";
        echo "</form>";
    } else {
        echo "Product not found";
    }

    $conn->close();
} else {
    echo "Invalid product ID";
}
?>
