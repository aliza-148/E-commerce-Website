<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id']) && is_numeric($_POST['id'])) {
    $id = $_POST['id'];
    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "hr_products";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if a new image is uploaded
    if ($_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["image"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        
        // Check file size
        if ($_FILES["image"]["size"] > 500000) {
            echo "Sorry, your file is too large.";
            exit;
        }

        // Allow certain file formats
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            exit;
        }

        // Move uploaded file
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            // Update product with new image path
            $imagePath = basename($_FILES["image"]["name"]);
            $sql = "UPDATE items SET name = '".$_POST['name']."', price = ".$_POST['price'].", details = '".$_POST['details']."', image = '$imagePath' WHERE id = $id";
        } else {
            echo "Sorry, there was an error uploading your file.";
            exit;
        }
    } else {
        // Update product without changing the image
        $sql = "UPDATE items SET name = '".$_POST['name']."', price = ".$_POST['price'].", details = '".$_POST['details']."' WHERE id = $id";
    }

    if ($conn->query($sql) === TRUE) {
        echo "Product updated successfully";
        header("location:hr.php");
    } else {
        echo "Error updating product: " . $conn->error;
    }

    $conn->close();
} else {
    echo "Invalid request";
}
?>
