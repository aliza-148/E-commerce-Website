<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HR Products</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header id="header">
    <h1>HR Products</h1>
    <form id="upload-form" method="post" action="upload.php" enctype="multipart/form-data">
      <label for="item-image">Image:</label>
      <input type="file" name="item-image" id="item-image">
      <label for="item-name">Name:</label>
      <input type="text" name="item-name" id="item-name">
      <label for="item-details">Details:</label>
      <textarea name="item-details" id="item-details"></textarea>
      <label for="item-price">Price ($):</label>
      <input type="number" name="item-price" id="item-price">
      <button type="submit">Upload Item</button>
    </form>
  </header>
  <main>
    <div id="container">
      <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "hr_products";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }

        // Get all items from database
        $sql = "SELECT * FROM items";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
          // Loop through each item and display it
          while($row = $result->fetch_assoc()) {
            echo "<div class='item' data-id='".$row['id']."'>";
            echo "<a href='product.php?id=".$row['id']."'><img style='width:250px; height:250px;' src='uploads/".$row['image']."' alt='".$row['name']."'></a>";
            echo "<h1>".$row['name']."</h1>";
            echo "<p>".$row['details']."</p>";
            echo "<span>$".$row['price']."</span>";
            echo "<div class='actions'>";
            echo "<button> <a href='update.php?id=".$row['id']."'>Update</a></button>";
            echo "<button> <a href='delete.php?id=".$row['id']."'>Delete</a></button>";
            echo "</div>";
            echo "</div>";
          }
        } else {
          echo "No items found";
        }

        $conn->close();
      ?>
    </div>
  </main>
  <footer>
    <p>&copy; All Rights Reserved by HR Developers</p>
  </footer>
</body>

<style>
  body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
}

header {
  background-color: #f1f1f1;
  padding: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

header h1 {
  margin: 0;
}

#upload-form {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

#upload-form label {
  font-weight: bold;
}

#upload-form input, #upload-form textarea {
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

main {
  padding: 20px;
}

#container {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 20px;
}

.item {
  width: 48%;
  background-color: #fff;
  box-shadow: 0 0 5px rgba
}
  </style>
</html>
