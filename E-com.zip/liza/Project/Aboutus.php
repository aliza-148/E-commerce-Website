<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - HIJABI</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background-color: #65000B;
            color: white;
        }
        .navbar .navbar-brand {
            font-family: 'Pacifico', cursive;
            font-size: 1.5rem;
            color: white;
        }
        .navbar .nav-link {
            color: #ffffff;
            margin-left: 20px;
        }
        .navbar .fa-shopping-cart {
            color: #ffffff;
            margin-left: 1rem;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
        h1, h2, h3 {
            color: #555;
            border-bottom: 2px solid #eee;
            padding-bottom: 5px;
        }
        p {
            margin-bottom: 15px;
            line-height: 1.8;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <img src="HIJABI logo.png" class="img-fluid" style="width: 10%;">
    <div class="collapse navbar-collapse">
        <ul class="navbar-nav me-auto">
            <li class="nav-item"><a class="nav-link" href="ShoppingWebsite.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="shoptable.php">Shop</a></li>
        </ul>
        <a class="nav-link" href="Addtocart.php"><i class="fas fa-shopping-cart"></i> Cart</a>
    </div>
</nav>

<div class="container">
    <h1>About Us - HIJABI</h1>
    <p>Welcome to HIJABI, your premier online destination for modest fashion. 
        At HIJABI, we are dedicated to providing a wide range of high-quality abayas, 
        niqabs, hijab caps, and stollers, catering to the discerning needs of our customers who embrace modesty without compromising style.</p>
    
    <h2>Our Vision</h2>
    <p>To empower individuals around the globe by offering fashionable,
         modest clothing choices that inspire confidence and reflect cultural diversity.</p>
    
    <h2>Our Mission</h2>
    <p>At HIJABI, our mission is to create an inclusive online 
        platform where modest fashion enthusiasts can discover, explore,
         and shop for the latest trends in a convenient and customer-focused environment.</p>
    
    <h2>Why Choose Us?</h2>
    <ul>
        <li>Extensive Selection: We curate a diverse collection of modest fashion items to suit every occasion and preference.</li>
        <li>Quality Assurance: Each product is carefully selected and crafted to meet our high standards of quality and craftsmanship.</li>
        <li>Customer Satisfaction: We prioritize customer satisfaction by offering a seamless shopping experience and dedicated support.</li>
        <li>Global Reach: We ship worldwide, ensuring that our customers from all corners of the world can access our products.</li>
    </ul>
    
    <h2>Contact Us</h2>
    <p>Have questions or feedback? We'd love to hear from you! Contact our customer support team at <a href="mailto:support@hijabi.com">support@hijabi.com</a>.</p>
</div>

</body>
</html>
