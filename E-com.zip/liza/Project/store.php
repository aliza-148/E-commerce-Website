<?php
session_start();
     $user_email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
          integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
          crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: black;
            background-color:white;
        }
        .navbar {
            background-color: #65000b;
            display: flex;
            justify-content: space-between;
            align-items: center;  
            padding: 10px 20px;
            color: black;
        }
        .navbar .nav-link {
            color: #ffffff;
            margin-left: 20px;
        }
        .navbar .fa-bag-shopping, .navbar .fa-user {
            color:black;
            margin-left: 1rem;
        }
        form {
            background-color:white;
            padding: 20px;
            border-radius: 5px;
            border-style:groove;
            filter: drop-shadow(10px red);
            width: 30%;
            margin: 20px auto;
        }
        label {
            font-weight: bold;
            color:black;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            background-color: #F1DFD3;
            color:black;
        }
        .h2 {
            display: flex;
            justify-content: center;
        }
        .file {
            margin-top: 10px;
        }
        .submit {
            background-color: #F9D326;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .submit:hover {
            background-color: #F0D9CB;
        }
        body {
            padding: 17px;
            background-color:white;
            font-family: 'Trebuchet MS', Arial, sans-serif;
        }
        .navbar {
            background-color:#65000B;
            color: white;
        }
        .navbar .navbar-brand {
            font-family: 'Pacifico', cursive;
            font-size: 1.5rem;
            color: white;
        }
        .navbar .nav-link {
            color: #ffffff;
            margin-left: 20px;
        }
        .navbar .fa-shopping-cart {
            color: #ffffff;
            margin-left: 1rem;
        }
        .table {
            max-width: 100%;
            border-collapse: collapse;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
            background-color: black;
            background-size: cover;
            background-position: center;
        }
        th, td {
            border: 1px solid #dddddd;
            padding: 8px;
            width: 500px;
            font-size: large;
        }
        th {
            background-color: White;
            color: black;
        }
        .edit {
            background-color: #4F4F51;
            color: white;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 3px;
            transition: background-color 0.3s, transform 0.3s;
        }
        .edit:hover {
            background-color: #6C757D;
            transform: scale(1.05);
        }
        .delete {
            background-color: #F58F7C;
            color: white;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 3px;
            transition: background-color 0.3s, transform 0.3s;
            margin-left: 5px;
        }
        .delete:hover {
            background-color: #F2C4CE;
            transform: scale(1.05);
        }
    </style>
</head>
<body>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$db_name = "shopping";
$conn = mysqli_connect($servername, $username, $password, $db_name);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productname = $_POST['productname'];
    $productquantity = $_POST['productquantity'];
    $productprice = $_POST['productprice'];
    $producttype = $_POST['producttype'];
    $image = $_FILES['image']['name'];
    $target = "uploads/" . basename($image);


    
    $sql = "INSERT INTO product (user_email, productname, productquantity, p_price, producttype, image) 
    VALUES ('$user_email', '$productname', '$productquantity', '$productprice', '$producttype', '$image')";

    if (mysqli_query($conn, $sql) && move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        echo "Product added successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>
<nav class="navbar navbar-expand-lg navbar-dark">
    <img src="HIJABI logo.png" class="img-fluid" style="width: 10%;">
    <div class="collapse navbar-collapse">
        <ul class="navbar-nav me-auto">
            <li class="nav-item"><a class="nav-link" href="ShoppingWebsite.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="storetable.php">Store</a></li>
        </ul>
        <a class="nav-link" href="cart.php"><i class="fas fa-shopping-cart"></i> Cart</a>
    </div>
</nav>
<br><br><br><br>

<h2 class="h2">Add YOUR Product HERE</h2>
<br><br>

<form method="post" action="" enctype="multipart/form-data">
    <div>
        <label>Product Name:</label><br>
        <input name="productname" required><br>
        <label>Product Quantity:</label><br>
        <input name="productquantity" type="number" required><br>
        <label>Price:</label><br>
        <input name="productprice" type="number" required><br>
        <label>Product type:</label><br>
        <select name="producttype" required>
            <option value="Georeggte">Georegtte</option>
            <option value="Cotton">Cotton</option>
            <option value="Silk">Silk</option>
            <option value="Jersey">Jersey</option>
            <option value="Chiffon">Chiffon</option>
            <option value="Lawn">Lawn</option>
            <option value="Georegtte Fabric Abaya">Georegtte Fabric Abaya</option>
            <option value="Nida Fabric Abaya">Nida Fabric Abaya</option>
            <option value="Zipper Abaya">Zipper Abaya</option>
            <option value="Niqab">Niqab</option>
            <option value="Hijabcap">HijabCap</option>
            <option value="Jewelery">Jewelery</option>
        </select><br><br>
       
        <label>Image:</label><br>
        <input class="file" type="file" name="image" required><br><br>
        <button class="submit" type="submit">BUY</button>
    </div>
    <p style="color:purple; display: flex; justify-content: center;">
        This shop provides you the best online buying and selling platform
    </p>
    <br>
</form>



<h1 style="text-align:center;color:black; border: radius 30px; border-style:double; margin: left 50px;">Store</h1>
<div class="table">
    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th>Product Name</th>
            <th>Product Quantity</th>
            <th>Product Price</th>
            <th>Product Type</th>
            <th>Image</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $sql = "SELECT * FROM product where user_email = '$user_email'";
        $result = mysqli_query($conn, $sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['productname'] . "</td>";
                echo "<td>" . $row['productquantity'] . "</td>";
                echo "<td>" . $row['p_price'] . "</td>";
                echo "<td>" . $row['producttype'] . "</td>";
                echo "<td><img src='uploads/" . $row['image'] . "' alt='Product Image' width='100'></td>";
                echo "<td>
                        <a href='editshop.php?eid=" . $row['id'] . "' class='edit' onclick='return confirm(\"Are you sure you want to edit this product?\");'>Edit</a>
                        <a href='deleteshop.php?productname=" . $row['productname'] . "' class='delete' onclick='return confirm(\"Are you sure you want to delete this product?\");'>Delete</a>
                    </td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='7'>No records found</td></tr>";
        }
        mysqli_close($conn);
        ?>
        </tbody>
    </table>
</div>
</body>
</html>
