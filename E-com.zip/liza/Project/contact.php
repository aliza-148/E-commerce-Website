<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "shopping";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $db_name);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve user input
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    // Check if email already exists
    $checkEmail = "SELECT `email` FROM `contact` WHERE `email` = '$email'";
    $result = mysqli_query($conn, $checkEmail);

    if ($result && mysqli_num_rows($result) > 0) {
        echo "<script>
                alert('Email already exists. Please use a different email.');
                window.location.href = 'contact.php';
              </script>";
    } else {
        // Insert data into database
        $sql = "INSERT INTO `contact` (`name`, `email`, `message`) 
                VALUES ('$name', '$email', '$message')";
        
        if (mysqli_query($conn, $sql)) {
            echo "<script>
                    alert('Message sent successfully!');
                    window.location.href = 'contact.php';
                  </script>";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Contact</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('shopping_cart.jpg');
            background-size: cover;
            margin: 0;
            padding: 0;
        }
        form {
            background: rgba(255, 255, 255, 0.8);
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 500px;
            margin: 20px auto;
        }
        h1 {
            color: #d56d5a;
            text-align: center;
        }
        label {
            display: block;
            margin-bottom: 8px;
        }
        input, textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        textarea {
            height: 80px;
        }
        .submit {
            background-color: #d56d5a;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 4px;
            width: 100%;
        }
        .submit:hover {
            background-color: #c68b80;
        }
        .login-link {
            text-align: center;
            margin-top: 20px;
        }
        .login-link a {
            color: #d56d5a;
            text-decoration: none;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
        .navbar {
            background-color: #65000B;
            color: white;
        }
        .navbar .navbar-brand {
            font-family: 'Pacifico', cursive;
            font-size: 1.5rem;
            color: white;
        }
        .navbar .nav-link {
            color: #ffffff;
            margin-left: 20px;
        }
        .navbar .fa-shopping-cart {
            color: #ffffff;
            margin-left: 1rem;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <img src="HIJABI logo.png" class="img-fluid" style="width: 10%;">
    <div class="collapse navbar-collapse">
        <ul class="navbar-nav me-auto">
            <li class="nav-item"><a class="nav-link" href="ShoppingWebsite.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="shoptable.php">Shop</a></li>
        </ul>
        <a class="nav-link" href="Addtocart.php"><i class="fas fa-shopping-cart"></i> Cart</a>
    </div>
</nav>

<form action="contact.php" method="post">
    <label for="name">Your name:</label>
    <input type="text" id="name" name="name" placeholder="Enter your name" required><br>
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" placeholder="Enter your email" required><br>
    <label for="message">Message:</label>
    <textarea id="message" name="message" placeholder="Enter your message" required></textarea><br>
    <button class="submit" type="submit">Submit</button>
</form>

</body>
</html>
