<!DOCTYPE html>
<html>
<head>
    <style>
        .product-item {
            border: 1px solid #ddd;
            padding: 16px;
            margin: 16px;
            border-radius: 8px;
            display: inline-block;
            width: 200px;
            text-align: center;
            background-color: #f9f9f9;
        }

        .product-item img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
        }

        .product-item div {
            margin-top: 8px;
        }

        .product-item p {
            margin: 8px 0;
        }

        .product-item button {
            background-color: #65000B;
            color: white;
            border: none;
            padding: 10px 16px;
            margin: 4px 2px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .product-item button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$db_name = "shopping";

$conn = mysqli_connect($servername, $username, $password, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$txtsearch = isset($_POST['search']) ? $_POST['search'] : '';
$sort = isset($_POST['sort']) ? $_POST['sort'] : '';

$sql = "SELECT * FROM product";
$conditions = [];

if ($txtsearch != "") {
    $conditions[] = "productname LIKE '%$txtsearch%'";
}

if (!empty($conditions)) {
    $sql .= " WHERE " . implode(" AND ", $conditions);
}

switch ($sort) {
    case 'price_asc':
        $sql .= " ORDER BY p_price ASC";
        break;
    case 'price_desc':
        $sql .= " ORDER BY p_price DESC";
        break;
    case 'date_asc':
        $sql .= " ORDER BY created_at ASC";
        break;
    case 'date_desc':
        $sql .= " ORDER BY created_at DESC";
        break;
    case 'name_asc':
        $sql .= " ORDER BY productname ASC";
        break;
    case 'name_desc':
        $sql .= " ORDER BY productname DESC";
        break;
}

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<div class="product-item">';
        echo '<img src="Uploads/' . $row['image'] . '" alt="' . $row['productname'] . '">';
        echo '<div>';
        echo '<p>Product Name: ' . $row['productname'] . '</p>';
        echo '<p>Product Type: ' . $row['producttype'] . '</p>';
        echo '<p>Product Price: ' . $row['p_price'] . '</p>';
        echo '<button onclick="buyNow(' . $row['id'] . ')">Buy</button>';
        echo '<button onclick="addToCart(' . $row['id'] . ')">Add to Cart</button>';
        echo '</div>';
        echo '</div>';
    }
} else {
    echo "No products found.";
}

mysqli_close($conn);
?>

<script>
function buyNow(productId) {
    window.location.href = 'buy.php?id=' + productId;
}

function addToCart(productId) {
    window.location.href = 'cart.php?id=' + productId;
}
</script>

</body>
</html>
