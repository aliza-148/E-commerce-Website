<!DOCTYPE html>
<html>
<head>
    <title>Shopping.com</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
          crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
          integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
          crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <link rel="stylesheet" href="Stylo.css">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<?php
session_start();
$isLoggedIn = isset($_SESSION['email']);
?>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a class="nav-link" href="Contact.php">Contact Us</a></li>
            <li class="nav-item"><a class="nav-link" href="#footer">For More details</a></li>
            <li class="nav-item"><a class="nav-link" href="Aboutus.php">About Us</a></li>
            <li class="nav-item"><a class="nav-link" href="Seller.php">Become a Seller</a></li>
        </ul>
    </div>
</nav>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <img src="HIJABI logo.png" class="img-fluid" style="width: 10%;">

    <div class="collapse navbar-collapse nav-button" id="navbarSupportedContent">
        <a class="nav-link" href="ShoppingWebsite.php">Home</a>
        <a class="nav-link" href="Addtocart.php"><i class="fas fa-shopping-cart"></i></a>
    </div>
    <div class="container-fluid">
        <?php if ($isLoggedIn): ?>
            <button><a href="store.php">Add products</a></button>
        <?php endif; ?>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" 
                data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" 
                aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="navbar">
            <?php if ($isLoggedIn): ?>
                <a href="shoplogout.php" class="nav-link" style="display: inline;"> logout
                    <i style="float:right;" class="fa-solid fa-right-from-bracket" onclick="logout()"></i></a>
            <?php else: ?>
                <a href="shoplogin.php" class="nav-link" style="display: inline;">Login</a>
                <a href="shopsignup.php" class="nav-link" style="display: inline;">Signup</a>
            <?php endif; ?>
        </div>
</nav>

<div class="search-container">
    <form action="search.php" method="post" class="form">
        <select style="padding: 5px; max-width: 100px;" name="sort" id="sort">
            <option value="">Sort by</option>
            <option value="price_asc">Price: Low to High</option>
            <option value="price_desc">Price: High to Low</option>
            <option value="date_asc">Date: Old to New</option>
            <option value="date_desc">Date: New to Old</option>
            <option value="name_asc">Name: A to Z</option>
            <option value="name_desc">Name: Z to A</option>
        </select>
        <input type="text" name="search" class="search-bar" autocomplete="off" placeholder="Search products...">
        <button type="submit" class="search-button">Search</button>
    </form>
</div>

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pop-Up Navigation Bar</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body   {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
             
            margin: 0;
            padding: 0;
            box-sizing: border-box;
    
        }

        .toggle-btn {
            margin: 20px;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            background-color:#65000b;

        }

        .main-content {
            padding: 20px;
            background-color: #fff;
        }

        .left-nav {
            width: 250px;
            background-color: #333;
            color: #fff;
            padding: 20px;
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh; 
            transform: translateX(-100%);
            transition: transform 0.3s ease-in-out;
        }

        .left-nav.active {
            transform: translateX(0);
        }

        .left-nav h2 {
            margin-bottom: 20px;
            font-size: 1.5em;
        }

        .left-nav ul {
            list-style: none;
        }

        .left-nav li {
            margin: 10px 0;
        }

        .left-nav a {
            color: #fff;
            text-decoration: none;
        }

        .left-nav a:hover {
            text-decoration:none;
         color:red;
        }

        .close-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 24px;
            cursor: pointer;
            position: absolute;
            top: 10px;
            right: 10px;
        }
    </style>
    <button id="toggle-nav" class="toggle-btn">All Categories of products</button>

        <div id="left-nav" class="left-nav">
        <button id="close-nav" class="close-btn">&times;</button>
        <h2>Product Categories</h2>
        <ul>
        <li class="dropdown-item">
                        <a href="#">Stollers Shop</a>
                        <ul class="dropdown">
                            <li class="dropdown-item"><a href="Georegtte.php">Georegtte Stollers</a></li>
                            <li class="dropdown-item"><a href="cotton.php">Cotton Stollers</a></li>
                             <li class="dropdown-item"><a href="Silk.php">Silk Stollers</a></li>
                            <li class="dropdown-item"><a href="Jersey.php">Jersey Stollers </a></li>
                            <li class="dropdown-item"><a href="Chiffon.php">Chiffon Stollers </a></li>
                          
                        </ul>
                    </li>
                    <li class="dropdown-item"><a href="shop.php">Abaya Shop</a>
                 <ul class="dropdown">
                            <li class="dropdown-item"><a href="Georegtte Abaya.php">Georegtte Fabric</a></li>
                            <li class="dropdown-item"><a href="Nida Abaya.php">Nida Fabric</a></li>
                             <li class="dropdown-item"><a href="ZipperAbaya.php">ZipperAbaya</a></li>

                        </ul>
                </li>
                <li class="dropdown-item"><a href="shop.php">Niqab Shop</a>
                 <ul class="dropdown">
                            <li class="dropdown-item"><a href="niqab.php">Niqab's</a></li>
                            
                        </ul>
                </li>
                <li class="dropdown-item"><a href="cap.php">Hijab Cap Shop</a>
                 <ul class="dropdown">
                            <li class="dropdown-item"><a href="cap.php">Hijab Cap's</a></li>
                           
                        </ul>
                </li>
                <li class="dropdown-item"><a href="Jewellery.php">Jewellery</a>
                 <ul class="dropdown">
                            <li class="dropdown-item"><a href="Jewellery.php">Jewellery</a></li>
                           
                        </ul>
                </li>
                </ul>
            </li>
        </ul>
    
                </li>
                
                <!-- <li class="nav-item">
                    <a class="nav-link" href="Click Here">Contact Us</a>
                </li> -->
            </ul>
            
            
        </ul>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const toggleNav = document.getElementById('toggle-nav');
            const leftNav = document.getElementById('left-nav');
            const closeNav = document.getElementById('close-nav');

            toggleNav.addEventListener('click', function () {
                leftNav.classList.toggle('active');
            });

            closeNav.addEventListener('click', function () {
                leftNav.classList.remove('active');
            });
        });
    </script>

        
    <div class="row mt-5">
        <div class="col-lg-12 text-center">
            <h2 class="display-4">Most Selling  Products</h2>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100" >
                <div class="card-body" style="background-color:#65000B; color:white; border-radius:10%; border-style:double;">
                <h4 class="card-title" >Stylish Abaya</h4>
                    <p class="card-text">Perfect for everyday wear</p>
                    <img src="ab1.jpg" alt="">    

                    <a href="Georegtte Abaya.php" class="btn btn-primary" style="background-color:#65000B;">View Product</a>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 mb-4" >
            <div class="card h-100">
                <div class="card-body" style="background-color:#65000B; color:white; border-radius:10%; border-style:double;">
                    <h4 class="card-title">Elegant Niqab</h4>
                    <p class="card-text">High-quality fabric</p>
                    <a href="niqab.php" class="btn btn-primary" style="background-color:#65000B;">
                        View Product</a>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body" style="background-color:#65000B; color:white; border-radius:10%; border-style:double;" >
                    <h4 class="card-title">Stylish Hijab Cap</h4>
                    <p class="card-text">Comfortable and trendy</p>
                    <a href="cap.php" class="btn btn-primary"  style="background-color:#65000B;">View Product</a>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100" >
                <div class="card-body" style="background-color:#65000B; color:white; border-radius:10%; border-style:double;">
                    <h4 class="card-title">Jewellery</h4>
                    <p class="card-text">Perfect for everyday wear</p>
                    <a href="Jewellery.php" class="btn btn-primary"  style="background-color:#65000B;">View Product</a>
                </div>
            </div>
        </div>
    </div>
</div>


         <div style="border-radius:5px; border-style:groove;padding:10px; margin: 10%; ">
        <div style="display:flex; justify-content:center;">
          <img src="HIJABI logo.png" class="img-fluid" style="width: 20%;"> 
            
        </div>
        <div class="container">
       
        <h5  style="display:flex; justify-content:center;">FOR MORE DETAILS CONTACT US:</h5> 

        <footer class="footer" id="footer">
    <br>
 <div style="justify-content:center;">
      <i class="fas fa-envelope"></i>       <span><b>Email Address:</b> hijabihere@gmail.com</span>
    </div> 
    <div style="display:flex;
    justify-content:center;">
      <i class="fas fa-map-marker-alt"></i>
      <span><b>Location:</b> City Nankana Sahib, Punjab, Pakistan</span>
    </div> 
    <div style="justify-content:center;">
      <i class="fas fa-phone"></i>
      <span><b>Office No:</b> 03003030366</span>
    </div> <br>
    <div style=" justify-content:center;">
      <i class="fas fa-phone"></i>
      <span><b>Tel No:</b> 303030565656</span> 
      <div class="social-media">
        Vist Our Intagram Profile :hijabianscollection
      <a href="https://www.instagram.com/hijabianscollection/"> <i class="fab fa-instagram"></i></a>
        </div><br>

</div>
       
        
    </div>

    
    </div>
</footer>
<script>
    function logout() {
        if (confirm("Are you sure you want to log out?")) {
            // Redirect to shoplogout.php for logout
            window.location.href = "shoplogout.php";
        }
    }
</script>
<p>&copy; 2024 HIJABI. All Rights Reserved.</p>

</body>
</html>
