<!DOCTYPE html>
<html>
<head>
    <title>Edit Product Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #2C2B30;
            color: #D6D6D6;
            margin: 0;
            padding: 0;
        }

        h2 {
            color: #F58F7C;
            text-align: center;
        }

        form {
            background-color: #4F4F51;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            width: 300px;
            margin: 20px auto;
        }

        label {
            font-weight: bold;
            color: #D6D6D6;
        }

        input[type="text"],
        input[type="number"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .button {
            background-color: #F58F7C; /* Light coral */
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 3px;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }

        .button:hover {
            background-color: #F2C4CE;
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <?php 
        // Database connection 
        $conn = mysqli_connect('localhost', 'root', '', 'shopping');

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $eid = intval($_GET['eid']);
        $select = "SELECT * FROM `product` WHERE id = $eid";
        $run = mysqli_query($conn, $select);
        $data = mysqli_fetch_assoc($run);
    ?>
    <h2>Edit Product</h2>
    <form method="post" enctype="multipart/form-data">
        <label>Product name:</label><br>
        <input type="text" name="productname" value="<?php echo htmlspecialchars($data['productname']); ?>" required><br>
        <label>Product Quantity:</label><br>
        <input type="number" name="productquantity" value="<?php echo htmlspecialchars($data['productquantity']); ?>" required><br>
        <label>Product Price:</label><br>
        <input type="text" name="productprice" value="<?php echo htmlspecialchars($data['p_price']); ?>" required><br>
        <label>Product Type:</label><br>
        <input type="text" name="producttype" value="<?php echo htmlspecialchars($data['producttype']); ?>" required><br>
        <label>Product Image:</label><br>
        <input type="file" name="image"><br>
        <button type="submit" name="submit" class="button">Update</button>
    </form>

    <?php
    if (isset($_POST['submit'])) {
        $productname = mysqli_real_escape_string($conn, $_POST['productname']);
        $productquantity = mysqli_real_escape_string($conn, $_POST['productquantity']);
        $productprice = mysqli_real_escape_string($conn, $_POST['productprice']);
        $producttype = mysqli_real_escape_string($conn, $_POST['producttype']);

        // Handle file upload
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $image = $_FILES['image']['name'];
            $target_dir = "uploads/";
            $target_file = $target_dir . basename($image);
            move_uploaded_file($_FILES['image']['tmp_name'], $target_file);

            // Update query with image
            $sql = "UPDATE product SET productname='$productname', 
            productquantity='$productquantity', p_price='$productprice', 
            producttype='$producttype', image='$image' WHERE id=$eid";
        } else {
            // Update query without image
            $sql = "UPDATE product SET productname='$productname', 
            productquantity='$productquantity', p_price='$productprice', 
            producttype='$producttype' WHERE id=$eid";
        }

        if (mysqli_query($conn, $sql)) {
            header('Location: ShoppingWebsite.php');
            exit();
        } else {
            echo "Error updating product: " . mysqli_error($conn);
        }

        // Close connection
        mysqli_close($conn);
    }
    ?>
</body>
</html>
