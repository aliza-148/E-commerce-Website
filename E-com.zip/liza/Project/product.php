<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hr_products";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM items WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
       
        echo "<h1>" . $row['name'] . "</h1>";
        echo "<img src='uploads/" . $row['image'] . "' width='200'><br>";
        echo "<p><strong>Price:</strong> $" . $row['price'] . "</p>";
        echo "<p><strong>Description:</strong> " . $row['details'] . "</p>";
    } else {
        echo "Product not found";
    }
} else {
    echo "Invalid product ID";
}

$conn->close();
?>
