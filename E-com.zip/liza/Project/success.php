<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Successful</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <style>
        body {
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            margin: auto;
        }
        .card {
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
            padding: 20px;
            margin-top: 20px;
        }
        .btn-primary {
            background-color: #65000B;
            border-color: #65000B;
        }
        .btn-primary:hover {
            background-color: #50000A;
            border-color: #50000A;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-body">
                <h1 class="card-title">Thank You for Your Purchase!</h1>
                <p class="card-text">Your order has been successfully placed. We will process it and send you a confirmation email shortly.</p>
                <p class="card-text">If you have any questions about your order, please <a href="contact.php">contact us</a>.</p>
                <a href="ShoppingWebsite.php" class="btn btn-primary">Return to Home</a>
            </div>
        </div>
    </div>
</body>
</html>
