<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$db_name = "shopping";

$conn = mysqli_connect($servername, $username, $password, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['Username'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmpassword = $_POST['confirmpassword'];
    $phone = $_POST['phone'];
    $dob = $_POST['dob'];
    $address = $_POST['address'];

    if ($password !== $confirmpassword) {
        echo "<div class='error'>Passwords do not match.</div>";
    } else {
$sql = "INSERT INTO signupshop (username, name, email, password, phone, dob, address)
 VALUES ('$username', '$name', '$email', '$password', '$phone', '$dob', '$address')";
        if (mysqli_query($conn, $sql)) {
            $_SESSION['email'] = $email;
            echo "<div class='success'>Signup successful. Redirecting...</div>";
            header('refresh:2; url=ShoppingWebsite.php');
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Signup or Login to place order</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('shopping_cart.jpg');
            background-size: cover;
            margin: 0;
            padding: 0;
        }
        form {
            background: rgba(255, 255, 255, 0.8); /* Semi-transparent white background */
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 500px;
            margin: 20px auto; /* Center the form horizontally */
        }
        h1 {
            color: #d56d5a;
            text-align: center;
        }
        label {
            display: block;
            margin-bottom: 8px;
        }
        input, textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        textarea {
            height: 80px;
        }
        .submit {
            background-color: #d56d5a;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 4px;
            width: 100%;
        }
        .submit:hover {
            background-color: #c68b80;
        }
        .login-link {
            text-align: center;
            margin-top: 20px;
        }
        .login-link a {
            color: #d56d5a;
            text-decoration: none;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
        .navbar {
            background-color: #65000B;
            color: white;
        }
        .navbar .navbar-brand {
            font-family: 'Pacifico', cursive;
            font-size: 1.5rem;
            color: white;
        }
        .navbar .nav-link {
            color: #ffffff;
            margin-left: 20px;
        }
        .navbar .fa-shopping-cart {
            color: #ffffff;
            margin-left: 1rem;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <img src="HIJABI logo.png" class="img-fluid" style="width: 10%;">
    <div class="collapse navbar-collapse">
        <ul class="navbar-nav me-auto">
            <li class="nav-item"><a class="nav-link" href="ShoppingWebsite.php">Home</a></li>
            <a class="nav-link" href="ShoppingWebsite.php#footer">Contact Us</a>
            </li>          </ul>
        <a class="nav-link" href="Addtocart.php"><i class="fas fa-shopping-cart"></i> Cart</a>
    </div>
</nav>

<form action="signuppro.php" method="post">
    <h1>Register your Account Here</h1>
    <label for="username">Username:</label>
    <input type="text" id="username" name="Username" placeholder="Enter your username" required><br>
    <label for="name">Your name:</label>
    <input type="text" id="name" name="name" placeholder="Enter your name" required><br>
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" placeholder="Enter your email" required><br>
    <label for="password">Password:</label>
    <input type="password" id="password" name="password" placeholder="Enter your password" required><br>
    <label for="confirmpassword">Confirm Password:</label>
    <input type="password" id="confirmpassword" name="confirmpassword" placeholder="Confirm your password" required><br>
    <label for="phone">Phone:</label>
    <input type="text" id="phone" name="phone" placeholder="Enter your phone number" required><br>
    <label for="dob">DOB:</label>
    <input type="date" id="dob" name="dob" required><br>
    <label for="address">Address:</label>
    <textarea id="address" name="address" placeholder="Enter your address" required></textarea><br>
    <input type="submit" class="submit" value="Signup">
</form>

<div class="login-link">
    <p>Already have an account? <a href="shoplogin.php">Login here</a></p>
</div>

</body>
</html>
