<?php
if(isset($_GET['productname'])) {
    $productname = $_GET['productname'];
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "shopping";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Prepare SQL statement
    $sql = "DELETE FROM product WHERE productname='$productname'";

    // Run SQL statement
    if (mysqli_query($conn, $sql)) {
        // Product deleted successfully
        mysqli_close($conn);
        // JavaScript for popup
        echo '<script language="javascript">';
        echo 'alert("Product deleted successfully");';
        echo 'window.location.href = "shoptable.php";'; // Redirect to previous page or another page
        echo '</script>';
    } else {
        echo "Error deleting product: " . mysqli_error($conn);
    }

} else {
    echo "Product name not provided.";
}
?>
