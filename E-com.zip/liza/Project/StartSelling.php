<!DOCTYPE html>
<html>
<head>
    <title>Signup or Login to place order</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <!-- Include FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('shopping_cart.jpg');
            background-size: cover;
            margin: 0;
            padding: 0;
        }

        form {
            background: rgba(255, 255, 255, 0.8); /* Semi-transparent white background */
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 500px;
            margin: 20px auto; /* Center the form horizontally */
        }

        h1 {
            color: #d56d5a;
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input, textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        textarea {
            height: 80px;
        }

        .submit {
            background-color: #d56d5a;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 4px;
            width: 100%;
        }

        .submit:hover {
            background-color: #c68b80;
        }

        .login-link {
            text-align: center;
            margin-top: 20px;
        }

        .login-link a {
            color: #d56d5a;
            text-decoration: none;
        }

        .login-link a:hover {
            text-decoration: underline;
        }

        .navbar {
            background-color: #65000B;
            color: white;
        }

        .navbar .navbar-brand {
            font-family: 'Pacifico', cursive;
            font-size: 1.5rem;
            color: white;
        }

        .navbar .nav-link {
            color: #ffffff;
            margin-left: 20px;
        }

        .navbar .fa-shopping-cart {
            color: #ffffff;
            margin-left: 1rem;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <img src="HIJABI logo.png" class="img-fluid" style="width: 10%;">
    <div class="collapse navbar-collapse">
        <ul class="navbar-nav me-auto">
            <li class="nav-item"><a class="nav-link" href="ShoppingWebsite.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="shoptable.php">Shop</a></li>
        </ul>
        <a class="nav-link" href="Addtocart.php"><i class="fas fa-shopping-cart"></i> Cart</a>
    </div>
</nav>

<form action="StartSelling.php" method="post">
    <h1>Register your Seller Account Here</h1>
    <label for="name">Your name:</label>
    <input type="text" id="name" name="name" placeholder="Enter your name" required><br>
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" placeholder="Enter your email" required><br>
    <label for="password">Password:</label>
    <input type="password" id="password" name="password" placeholder="Enter your password" required><br>
    <label for="confirmpassword">Confirm Password:</label>
    <input type="password" id="confirmpassword" name="confirmpassword" placeholder="Confirm password" required><br>
    <label for="businessname">Business Name:</label>
    <input type="text" id="businessname" name="businessname" placeholder="Enter your Business name" required><br>
    <button class="submit" type="submit">Sign Up</button>
    <div class="login-link">
        <p>Already have an account? <a href="shoplogin.php">Log in</a></p>
    </div>
</form>

<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "shopp";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $db_name);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Escape user inputs for security
    $name =  $_POST['name'];
    $email =  $_POST['email'];
    $password =  $_POST['password'];
    $businessname =  $_POST['businessname'];

    // Insert new seller into database
    $sql = "INSERT INTO sellers (name, email, password, businessname)
            VALUES ('$name', '$email', '$password', '$businessname')";

    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
        header("Location: HijabiSeller.php");

    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    // Close connection
    mysqli_close($conn);
}
?>

</body>
</html>
