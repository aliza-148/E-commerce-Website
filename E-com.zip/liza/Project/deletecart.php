<?php
// Retrieve the product id from the URL
$id = $_GET['id'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shopping";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Prepare SQL statement to delete based on id
$sql = "DELETE FROM cart WHERE id='$id'";

if (mysqli_query($conn, $sql)) {
    // Redirect back to Addtocart.php after deletion
    header("location: Addtocart.php");
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}

mysqli_close($conn);
?>
