<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "shopping";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve cart count
$cart_count = 0;
$sql = "SELECT COUNT(*) as count FROM cart";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $cart_count = $row['count'];
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Phones</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
          crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
          integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
          crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <style>
        body {
            padding: 17px;
            background-image: url('shopping cart.jpg');
            background-size: cover;
            font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 
            'Lucida Sans', Arial, sans-serif;
            transition: all 1s ease;
        }
        .navbar {
            background-color: #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            color: white;
        }

        .navbar .navbar-brand {
            font-family: 'Pacifico', cursive;
            font-size: 1.5rem;
            color: white;
        }

        .navbar .nav-link {
            color: #ffffff;
            margin-left: 20px;
        }

        .navbar .nav-link:hover {
            color: #ffbb00;
        }

        .navbar .fa-shopping-cart {
            color: #ffffff;
            margin-left: 1rem;
            position: relative;
        }

        .navbar .fa-shopping-cart::after {
            content: "<?php echo $cart_count; ?>";
            position: absolute;
            top: -10px;
            right: -10px;
            background-color: red;
            color: white;
            border-radius: 50%;
            padding: 2px 5px;
            font-size: 12px;
        }

        .row {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 1rem;
        }

        .col-lg-3 {
            border: 1px solid #ddd;
            border-radius: 20px;
            box-shadow: 0 0 10px rgba(53, 81, 193, 0.1);
            background-color: #f5f5f5;
            padding: 17px;
            text-align: center;
        }

        .img-fluid {
            border-radius: 10px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            max-width: 100%;
            height: auto;
            margin-bottom: 1rem;
        }

        .img-fluid:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        h3 {
            margin-bottom: 0.5rem;
        }

        p {
            margin: 0.5rem 0;
        }

        button {
            margin-top: 1rem;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="#">SHOPILO</a>
    <div class="collapse navbar-collapse nav-button" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="ShoppingWebsite.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="shoptable.php">Shop</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="clickhere.php">Contact Us</a>
                </li>
            </ul>
            
        
        <a class="nav-link" href="cart.php"><i class="fas fa-shopping-cart"></i> Cart</a>
    </div>
</nav>
<br>
<br>
<br>
<br>

<div class="row">
    <div class="col-lg-3 col-md-6 col-sm-12">
        <img class="img-fluid" src="Apple-iPhone-12-Pro-Max-All.jpg" alt="Iphone 12 pro max">
        <h3>Iphone 12 pro max</h3>
        <p>In Stock</p>
        <p>$200</p>
        <form action="Addtocart.php" method="post">
            <input type="hidden" name="productname" value="Iphone 12 pro max">
            <input type="hidden" name="productquantity" value="1">
            <input type="hidden" name="productprice" value="200">
            <input type="hidden" name="producttype" value="Phone">
            <input type="hidden" name="image" value="Apple-iPhone-12-Pro-Max-All.jpg">
            <button type="submit" class="btn btn-primary">Add to Cart</button>
        </form>
        <form action="shop.php" method="post">
            <button type="submit" class="btn btn-primary">Shop</button>
        </form>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-12">
        <img class="img-fluid" src="samsung.jpg" alt="Samsung">
        <h3>Samsung</h3>
        <p>In Stock</p>
        <p>$200</p>
        <form action="Addtocart.php" method="post">
            <input type="hidden" name="productname" value="Samsung">
            <input type="hidden" name="productquantity" value="1">
            <input type="hidden" name="productprice" value="200">
            <input type="hidden" name="producttype" value="Phone">
            <input type="hidden" name="image" value="samsung.jpg">
            <button type="submit" class="btn btn-primary">Add to Cart</button>
        </form>
        <form action="shop.php" method="post">
            <button type="submit" class="btn btn-primary">Shop</button>
        </form>
    </div>
    
    <div class="col-lg-3 col-md-6 col-sm-12">
        <img class="img-fluid" src="iphone 13.jpg" alt="Iphone 13 pro max">
        <h3>Iphone 13 pro max</h3>
        <p>In Stock</p>
        <p>$400</p>
        <form action="Addtocart.php" method="post">
            <input type="hidden" name="productname" value="Iphone 13 pro max">
            <input type="hidden" name="productquantity" value="1">
            <input type="hidden" name="productprice" value="400">
            <input type="hidden" name="producttype" value="Phone">
            <input type="hidden" name="image" value="iphone 13.jpg">
            <button type="submit" class="btn btn-primary">Add to Cart</button>
        </form>
        <form action="shop.php" method="post">
            <button type="submit" class="btn btn-primary">Shop</button>
        </form>  
    </div>

    <div class="col-lg-3 col-md-6 col-sm-12">
        <img class="img-fluid" src="vivoY100.jpg" alt="Vivo Y100">
        <h3>Vivo Y100</h3>
        <p>In Stock</p>
        <p>$90</p>
        <form action="Addtocart.php" method="post">
            <input type="hidden" name="productname" value="Vivo Y100">
            <input type="hidden" name="productquantity" value="1">
            <input type="hidden" name="productprice" value="90">
            <input type="hidden" name="producttype" value="Phone">
            <input type="hidden" name="image" value="vivoY100.jpg">
            <button type="submit" class="btn btn-primary">Add to Cart</button>
        </form>
        <form action="shop.php" method="post">
            <button type="submit" class="btn btn-primary">Shop</button>
        </form>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-12">
        <img class="img-fluid" src="oppo.jpg" alt="Oppo">
        <h3>Oppo</h3>
        <p>In Stock</p>
        <p>$50</p>
        <form action="Addtocart.php" method="post">
            <input type="hidden" name="productname" value="Oppo">
            <input type="hidden" name="productquantity" value="1">
            <input type="hidden" name="productprice" value="50">
            <input type="hidden" name="producttype" value="Phone">
            <input type="hidden" name="image" value="oppo.jpg">
            <button type="submit" class="btn btn-primary">Add to Cart</button>
        </form>
        <form action="shop.php" method="post">
            <button type="submit" class="btn btn-primary">Shop</button>
        </form>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-12">
        <img class="img-fluid" src="Huawei.jpg" alt="Huawei">
        <h3>Huawei</h3>
        <p>In Stock</p>
        <p>$40</p>
        <form action="Addtocart.php" method="post">
            <input type="hidden" name="productname" value="Huawei">
            <input type="hidden" name="productquantity" value="1">
            <input type="hidden" name="productprice" value="40">
            <input type="hidden" name="producttype" value="Phone">
            <input type="hidden" name="image" value="Huawei">
            <button type="submit" class="btn btn-primary">Add to Cart</button>
        </form>
        <form action="shop.php" method="post">
            <button type="submit" class="btn btn-primary">Shop</button>
        </form>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-12">
        <img class="img-fluid" src="Xaimo.png" alt="Xiaomi">
        <h3>Xiaomi</h3>
        <p>In Stock</p>
        <p>$30</p>
        <form action="Addtocart.php" method="post">
            <input type="hidden" name="productname" value="Xiaomi">
            <input type="hidden" name="productquantity" value="1">
            <input type="hidden" name="productprice" value="30">
            <input type="hidden" name="producttype" value="Phone">
            <input type="hidden" name="image" value="Xaimo.png">
            <button type="submit" class="btn btn-primary">Add to Cart</button>
        </form>
        <form action="shop.php" method="post">
            <button type="submit" class="btn btn-primary">Shop</button>
        </form>
    </div>
</div>
</body>
</html>
