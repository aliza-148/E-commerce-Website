<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$db_name = "shopping";

$conn = mysqli_connect($servername, $username, $password, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handle POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $payment_method = $_POST['payment_method'];
    $user_id = @$_SESSION['user_id']; // Assuming you have a user session

    // Get cart items
    $cart_sql = "SELECT * FROM cart WHERE submitted = 0"; // Only get unsubmitted items
    $cart_result = mysqli_query($conn, $cart_sql);

    // Check if cart is empty
    if ($cart_result->num_rows > 0) {
        // Begin transaction
        mysqli_begin_transaction($conn);

        try {
            while ($row = mysqli_fetch_assoc($cart_result)) {
                $product_id = $row['id']; // Assuming you have an 'id' column for each product in the cart
                $productquantity = $row['productquantity'];
                $p_price = $row['p_price'];
                $total_amount = $p_price * $productquantity;

                // Save the order details in the database
                $order_sql = "INSERT INTO orders (user_id, product_id, quantity, total_amount, payment_method) 
                              VALUES ('$user_id', '$product_id', '$productquantity', '$total_amount', '$payment_method')";

                if (!mysqli_query($conn, $order_sql)) {
                    throw new Exception("Error inserting order: " . mysqli_error($conn));
                }
            }

            // Mark items as submitted only after the payment details are successfully inserted
            $update_cart_sql = "UPDATE cart SET submitted = 1 WHERE submitted = 0";
            if (!mysqli_query($conn, $update_cart_sql)) {
                throw new Exception("Error updating cart: " . mysqli_error($conn));
            }

            // Commit transaction
            mysqli_commit($conn);

            // Redirect based on payment method
            if ($payment_method == 'Bank Account') {
                header("Location: payment.php");
            } else if ($payment_method == 'Cash on Delivery') {
                header("Location: Cash.php");
            }
            exit;
        } catch (Exception $e) {
            // Rollback transaction on error
            mysqli_rollback($conn);
            echo "Transaction failed: " . $e->getMessage();
            exit;
        }
    } else {
        echo "Your cart is empty.";
        exit;
    }
}

mysqli_close($conn);
?>
