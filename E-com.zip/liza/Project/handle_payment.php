<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "shopping"; // Use your actual database name

$conn = mysqli_connect($servername, $username, $password, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $account_number = $_POST['IBN'];
    $mpin = $_POST['MPIN'];

    // Validate inputs
    if (!empty($account_number) && !empty($mpin)) {
        // Hash MPIN for security
        $hashed_mpin = password_hash($mpin, PASSWORD_BCRYPT);

        $sql = "INSERT INTO payment_details (user_id, account_number, mpin)
                VALUES (1, '$account_number', '$hashed_mpin')"; // Replace 1 with actual user ID if applicable

        if (mysqli_query($conn, $sql)) {
            echo "Payment details saved successfully.";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Please fill in all fields.";
    }
}

mysqli_close($conn);
?>
