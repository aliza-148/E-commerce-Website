<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "shopping";

$conn = mysqli_connect($servername, $username, $password, $db_name);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$user_id=@$_SESSION['id'];
echo $user_id;
$id = $_GET['id'];


$sql_check = "SELECT * FROM cart WHERE id = $id";
$result_check = mysqli_query($conn, $sql_check);

if ($result_check->num_rows == 0) {
    
    $sql_product = "SELECT * FROM product WHERE id = $id";
    $result_product = mysqli_query($conn, $sql_product);
   
    if ($result_product->num_rows > 0) {
        $product = mysqli_fetch_assoc($result_product);
       $sql_insert = "INSERT INTO cart (user_id,id, productname, productquantity, p_price, producttype, image) 
                       VALUES ('$user_id','{$product['id']}', '{$product['productname']}', '{$product['productquantity']}', 
                       '{$product['p_price']}', '{$product['producttype']}', '{$product['image']}')";
      $insert =  mysqli_query($conn, $sql_insert);
        if ($insert) {
           
        header("location: Addtocart.php");

        }
    }
    
}
else{
    header("location: Addtocart.php");
}
?>
