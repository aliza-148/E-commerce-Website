<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$db_name = "shopping";

$conn = mysqli_connect($servername, $username, $password, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$login_message = ""; // Initialize a variable to store the login message

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $select = "SELECT * FROM signupshop WHERE email= '$email' AND password='$password'";
    $query = mysqli_query($conn, $select);

    if (!$query) {
        $login_message = "<div class='error'>Query unsuccessful: " . mysqli_error($conn) . "</div>";
    } else {
        $result = mysqli_num_rows($query);
        if ($result == 1) {
            $_SESSION['email'] = $email;
            
            // user id sessioning 
            $select="SELECT * FROM `signupshop` where email='$email'";
            $que=mysqli_query($conn,$select);
            $data=mysqli_fetch_assoc($que);

            $user_id=$data['id'];

            $_SESSION['id']=$user_id;

            $login_message = "<div class='success'>Login successful. Redirecting...</div>";
            echo "<script>
                setTimeout(function(){
                    window.location.href = 'ShoppingWebsite.php';
                }, 2000);
 alert('login successful!');
             </script>";
        } 
        
    }
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            background-color: #F5F5F5; /* Light grey background for the whole page */
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background-color: #800000; /* Maroon color for the navbar */
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .navbar a {
            color: #FFFFFF; /* White color for the links */
            text-decoration: none;
            font-size: 18px;
            padding: 10px;
        }
        .navbar a:hover {
            background-color: #660000; /* Darker maroon on hover */
            border-radius: 4px;
        }
        .inner {
            background-color: #FFFFFF; /* White color for the form container */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            margin: 50px auto;
        }
        h1 {
            color: #800000; /* Maroon color */
            text-align: center;
            margin-bottom: 20px;
        }
        .input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #DDD;
            border-radius: 4px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #800000; /* Maroon color */
            color: #FFFFFF; /* White color */
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #660000; /* Darker maroon */
        }
        .error {
            color: #FF0000; /* Red color for errors */
            text-align: center;
            margin-top: 10px;
        }
        .success {
            color: #008000; /* Green color for success */
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="ShoppingWebsite.php">
            <i class="fas fa-home"></i> Home
        </a>
    </div>
    <div class="inner">
        <form class="form" method="POST">
            <h1>Login Here</h1>
            <div>
                <input type="email" name="email" class="input" placeholder="Enter your email to login" required>
            </div>
            <div>
                <input type="password" name="password" class="input" placeholder="Enter your password to login" required>
            </div>
            <button name="login">Login</button>
        </form>
    </div>
    <!-- Font Awesome for Home icon -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
</body>
</html>
