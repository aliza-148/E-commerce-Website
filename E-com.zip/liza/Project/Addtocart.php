<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$db_name = "shopping";

$conn = mysqli_connect($servername, $username, $password, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$email = @$_SESSION['email'];
$user_id = @$_SESSION['id'];
if (empty($email)) {
    $cart_ = "login";
    header("location:shoplogin.php?cart_=$cart_");
    exit();
}

// Handle the quantity update
if (isset($_POST['update_quantity'])) {
    $cart_id = $_POST['cart_id'];
    $new_quantity = $_POST['quantity'];
    $update_cart_query = "UPDATE cart SET productquantity=$new_quantity, p_price=p_price/$new_quantity*$new_quantity WHERE id=$cart_id";
    if (mysqli_query($conn, $update_cart_query)) {
        echo "<p style='color: green; text-align: center;'>Cart updated successfully.</p>";
    } else {
        echo "<p style='color: red; text-align: center;'>Error: " . mysqli_error($conn) . "</p>";
    }
}

// Store the grand total in a session variable
$sql = "SELECT * FROM cart WHERE user_id='$user_id'";
$get = $conn->query($sql);
$total = 0;

if ($get->num_rows > 0) {
    while ($row = $get->fetch_assoc()) {
        $total += $row['p_price'] * $row['productquantity'];
    }
    $_SESSION['total'] = $total; // Store the total in a session variable
} else {
    $_SESSION['total'] = 0;
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <style>
        body {
            padding: 17px;
            background-color: white;
            font-family: 'Trebuchet MS', Arial, sans-serif;
        }

        .navbar {
            background-color: #65000B;
            color: white;
        }

        .navbar .navbar-brand {
            font-family: 'Pacifico', cursive;
            font-size: 1.5rem;
            color: white;
        }

        .navbar .nav-link {
            color: #ffffff;
            margin-left: 20px;
        }

        .navbar .fa-shopping-cart {
            color: #ffffff;
            margin-left: 1rem;
        }

        table {
            width: 100%;
            margin-top: 20px;
        }

        th,
        td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #333;
            color: white;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        img {
            max-width: 100px;
            border-radius: 10px;
        }

        .btn {
            margin-right: 5px;
        }

        .quantity-input {
            width: 60px;
            text-align: center;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <img src="HIJABI logo.png" class="img-fluid" style="width: 10%;">
    <div class="collapse navbar-collapse">
        <ul class="navbar-nav me-auto">
            <li class="nav-item"><a class="nav-link" href="ShoppingWebsite.php">Home</a></li>
            <li class="nav-item">
    <a class="nav-link" href="ShoppingWebsite.php#footer">Contact Us</a>
</li>        </ul>
        <a class="nav-link" href=""><i class="fas fa-shopping-cart"></i> Cart</a>
    </div>
</nav>

    <table class="table">
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Type</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $conn = mysqli_connect($servername, $username, $password, $db_name);

            $sql = "SELECT * FROM cart where user_id='$user_id'";
            $get = $conn->query($sql);
            $total = 0; 
            if ($get->num_rows > 0) {
                while ($row = $get->fetch_assoc()) {
                    $total += $row['p_price'] * $row['productquantity']; 
                    echo "<tr>
                        <td>{$row['productname']}</td>
                        <td>
                            <form action='' method='POST'>
                                <input type='hidden' name='cart_id' value='{$row['id']}'>
                                <input type='number' name='quantity' value='{$row['productquantity']}' min='1' class='quantity-input'>
                                <button type='submit' name='update_quantity' class='btn btn-info'>Update</button>
                            </form>
                        </td>
                        <td>\${$row['p_price']}</td>
                        <td>{$row['producttype']}</td>
                        <td><img src='uploads/{$row['image']}' alt='{$row['image']}'></td>
                        <td>";
                    if (isset($row['submitted']) && $row['submitted']) {
                        echo "Submitted";
                    } else {
                        echo "<a href='deletecart.php?id={$row['id']}' class='delete' onclick='return confirm(\"Are you sure you want to delete this product?\");'>Delete</a>
                              <a href='buy.php?id={$row['id']}' class='btn btn-success'>Buy</a>";
                    }
                    echo "</td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No items in the cart</td></tr>";
            }
            $conn->close();
            ?>
        </tbody>
    </table>
    <div class="container">
        <h3>Grand Total: $<?php echo $_SESSION['total']; ?></h3>
        <form action="submit.php" method="POST">
            <div class="form-group">
                <label for="payment_method">Choose Payment Method:</label><br>
                <input type="radio" id="bank_account" name="payment_method" value="Bank Account" required>
                <label for="bank_account">Bank Account</label><br>
                <input type="radio" id="cash_on_delivery" name="payment_method" value="Cash on Delivery" required>
                <label for="cash_on_delivery">Cash on Delivery</label><br>
            </div>
            <button type="submit" class="btn btn-primary">Final purchasing</button>
        </form>
    </div>
</body>
</html>
